<?php
/*
	errors/404.config.php
	Caballero Website Manager
	Jason M. Knight
	Last Modified: 07 Feb 2023 07:58 UTC
*/

define('ERROR_TITLE', '404 Not Found');
include 'errors/errors.inc.php';
