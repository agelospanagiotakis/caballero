<?php
/*
	pages/index.config.php
	Caballero Website Manager
	Jason M. Knight
	Last Modified: 10 Feb 2023 00:16 UTC
*/

Document::addMeta(
	'description',
	'A demo of very basic semi-static site building with PHP featuring support for multiple templates, page caching, and markup minification.'
);