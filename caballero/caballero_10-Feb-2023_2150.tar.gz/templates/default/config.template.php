<?php
/*
	templates/default/config.template.php
	Caballero Website Manager
	Jason M. Knight
	Last Modified: 10 Feb 2023 19:55 UTC
*/

Document::addPreload('templates/default/fonts/interface-Regular.woff2');
Document::addModal('demo');