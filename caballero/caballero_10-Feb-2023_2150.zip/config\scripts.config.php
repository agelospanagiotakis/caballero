<?php
/*
	config/scripts.config.php
	Caballero Website Manager
	Jason M. Knight
	Last Modified: 10 Feb 2023 00:14 UTC
*/

Document::addScriptFile('scripts/library.js', [], true);