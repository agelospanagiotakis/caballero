<?php
/*
	errors/invalidURI.config.php
	Caballero Website Manager
	Jason M. Knight
	Last Modified: 07 Feb 2023 07:59 UTC
*/

define('ERROR_TITLE', '400 Bad Request');
include 'errors/errors.inc.php';
