<?php
$title = 'Demo Modal';