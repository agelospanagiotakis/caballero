<p>
	Just some stock placeholder text to show that the modal dialog system works.
</p><p>
	Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nunc pellentesque, libero et facilisis rutrum, lectus urna faucibus nulla, id ultricies orci mauris nec tellus. Phasellus efficitur neque sed velit mattis, vitae viverra metus posuere. Ut sodales pellentesque tellus vel volutpat. Fusce volutpat porttitor nisl sit amet aliquam. Praesent sed nibh nisl. Mauris ornare augue sit amet lacinia mollis. Donec non tortor at tellus euismod interdum.
</p>