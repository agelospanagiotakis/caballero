<section class="index">
	<h2>Documentation Index</h2>
	<p>
		The following subsystem documentation lets you come up to speed quickly on using this system.
	</p>
	<ul>
		<li><a href="docs-definePrefixes">define() Prefixes</a></li>
		<li><a href="docs-defines">Caballero's Defines</a></li>
		<li><a href="docs-directories">Directory Structure</a></li>
		<li><a href="docs-fileExtensions">File Extensions</a></li>
		<li><a href="docs-pageCreation">Creating New Pages</a></li>
	</ul>
<!-- .index --></section>